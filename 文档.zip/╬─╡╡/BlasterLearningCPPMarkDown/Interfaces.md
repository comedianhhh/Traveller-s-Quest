# InteractWithCrosshairsInterface

玩家角色实现这个接口，是用来判断武器击中的对象是不是玩家角色。此接口暂时不需要实现任何功能。

```cpp
UINTERFACE(MinimalAPI)
class UInteractWithCrosshairsInterface : public UInterface
{
 GENERATED_BODY()
};

/**
 * 
 */
class BLASTERLEARING_API IInteractWithCrosshairsInterface
{
 GENERATED_BODY()

 // Add interface functions to this class. This is the class that will be inherited to implement this interface.
public:
};
```
